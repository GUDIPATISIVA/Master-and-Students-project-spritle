import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";
import jwt_Decode from "jwt-decode"

export default function Header() {
    const [data, setData]: any = useState([]);
    const [showMenu, setShowMenu] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem("token");
        if (token) {
            const decode = jwt_Decode(`${token}`);
            setData(decode);
        }
    }, [

    ]);

    const signOut = () => {
        localStorage.removeItem("token");
        navigate("/signin");
    }
    return (
        <div className="h-16 bg-slate-500 flex">
            <div onClick={() => setShowMenu(!showMenu)} className=" relative p-4 rounded-full border-2 w-12 h-12 text-center m-auto ml-auto mr-4 flex items-center justify-center text-3xl cursor-pointer" id="menu-button" aria-expanded="true" aria-haspopup="true">
                {data.username?.slice(0, 1).toUpperCase()}
                {showMenu ? (
                    <div className="z-50 absolute right-0 bottom-[-44px] text-lg w-48 bg-white border-2 rounded-lg border-gray-800" onClick={() => { signOut() }}>Sign Out</div>
                ) : ""}
            </div>
        </div>
    )
}