import { useEffect, useState } from "react"
import jwt_Decode from "jwt-decode"
import { toast } from "react-toastify";
import Action from "../services";

export default function Master() {
    const [modal, setModal] = useState(false);
    const [text, setText] = useState("");
    const [data, setData]: any = useState([]);
    const [myquestions, setMyquestions]: any = useState([]);

    useEffect(() => {
        const token = localStorage.getItem("token");
        if (token) {
            const decode: any = jwt_Decode(`${token}`);
            setData(decode);
            getQuestions(decode.username);
        }
    }, []);

    const getQuestions = async (name: any) => {
        const result = await Action.getQuestions({ name: name });
        if (result.status) {
            setMyquestions(result.result);
        } else {
            toast.error(result.errors);
        }
    }

    const addQuestion = async () => {
        if (text === "") {
            toast.error("Please input your question again!");
        } else {
            const question = {
                name: data.username,
                question: text
            }
            const result = await Action.addQuestion(question);
            if (result.status) {
                toast.success("Succcessfully added!");
                setModal(false);
                setText("");
                getQuestions(data.username);
            } else {
                toast.error("Failed to adding new Question!");
            }
        }
    }
    return (
        <>
            <div className="flex flex-col p-7 justify-center items-center relative">
                <button onClick={() => { setModal(!modal) }} className="ml-auto border-2 border-slate-600 p-2 rounded-xl">Add Question</button>
                <div className="grid gap-3 w-full mt-6">
                    {myquestions?.map((element: any, index: any) => (
                        <div key={index} className="bg-cyan-400 cursor-pointer p-3 border-[1px] rounded-lg pr-6">
                            {element.question}
                            <div className="flex flex-col mt-5">
                                {element.answers?.map((e: any, key: number) => (
                                    <div key={key} className="bg-cyan-400 cursor-pointer p-3 border-[1px] rounded-lg flex justify-between pr-6 mb-2">{e.answer}</div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
                {modal ? (
                    <div className="absolute lg:w-3/4 md:w-4/5 w-[80%] h-96 rounded-xl border-[1px] top-[20vh] border-slate-800 shadow-md p-4 bg-pink-200">
                        <textarea value={text} onChange={(e) => { setText(e.target.value) }} placeholder="Input your Question" className="p-12 w-full border-[1px] border-slate-800 h-[80%]" />
                        <div className="flex mt-4">
                            <button onClick={() => { addQuestion() }} className="ml-auto border-[1px] border-slate-800 px-[20px] mr-5">Add</button>
                            <button onClick={() => { setModal(false) }} className="border-[1px] border-slate-800 px-[20px]">Cancel</button>
                        </div>
                    </div>
                ) : ""}
            </div>
        </>
    )
}