import { useEffect, useState } from "react"
import { toast } from "react-toastify";
import jwt_Decode from "jwt-decode"
import Action from "../services";

export default function Student() {
    const [modal, setModal] = useState(false);
    const [data, setData]: any = useState([]);
    const [text, setText] = useState("");
    const [selectedItem, setSelectedItem] = useState(0);
    const [openCalculator, setOpenCalculator] = useState(false);
    const [userData, setUserData]: any = useState([]);
    const [firstNum, setFirstNum] = useState(0);
    const [operator, setOperator] = useState("");
    const [secondNum, setSecodNum] = useState(0);
    const [result, setResult] = useState("");

    useEffect(() => {
        const token = localStorage.getItem("token");
        if (token) {
            const decode: any = jwt_Decode(`${token}`);
            setUserData(decode);
        }
        getQuestions();
    }, [])

    const getQuestions = async () => {
        const result = await Action.getAllQuestions();
        if (result.status) {
            setData(result.result);
        } else {
            toast.error(result.errors);
        }
    }

    const openModal = (item: number) => {
        setModal(true);
        setSelectedItem(item);
    }

    const answer = async () => {
        const selectedData = {
            id: data[selectedItem]._id,
            username: userData.username,
            answer: text
        }
        const result = await Action.answerQuestion(selectedData);
        if (result.status) {
            toast.success("You have successfully submitted your answer");
            getQuestions();
            setText("");
            setModal(false);
        } else {
            toast.error("Something Wrong. Please try again");
        }
    }

    const calculation = (num: number) => {
        console.log(operator);
        if (operator === "") {
            setFirstNum(firstNum * 10 + num);
            setResult((firstNum * 10 + num).toString());
        } else {
            setResult(result + num);
            setSecodNum(secondNum * 10 + num);
        }
    }

    const operation = (op: string) => {
        if (op === "=") {
            switch (operator) {
                case "+":
                    setResult((Number(firstNum) + Number(secondNum)).toString());
                    break;
                case "-":
                    setResult((Number(firstNum) - Number(secondNum)).toString());
                    break;
                case "*":
                    setResult((Number(firstNum) * Number(secondNum)).toString());
                    break;
                case "/":
                    setResult(Math.floor(firstNum / secondNum).toString());
            }
            setFirstNum(0);
            setSecodNum(0);
            setOperator("");
        } else {
            setOperator(op);
            setResult(result + op);
        }
    }

    const clear = () => {
        setFirstNum(0);
        setSecodNum(0);
        setOperator("");
        setResult("");
    }

    return (
        <div className="grid gap-3 w-full mt-6 p-12">
            <button onClick={() => { setOpenCalculator(!modal) }} className="ml-auto border-2 border-slate-600 p-2 rounded-xl">Open Calculater</button>
            {data?.map((element: any, index: number) => (
                <div key={index} className="bg-cyan-400 cursor-pointer p-3 border-[1px] rounded-lg pr-6" onClick={() => { openModal(index) }}>
                    {element.question}
                    <br />
                    <div className="flex flex-col mt-5">
                        {element.answers?.map((e: any, key: number) => (
                            <div key={key} className="bg-cyan-400 cursor-pointer p-3 border-[1px] rounded-lg flex justify-between pr-6 mb-2">{e.answer}</div>
                        ))}
                    </div>
                    {/* <svg className="-mr-1 h-5 w-5 text-gray-900" viewBox="0 0 20 20" >
                        <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
                    </svg> */}
                </div>
            ))}
            {modal ? (
                <div className="h-full w-full absolute top-0 left-0 flex justify-center items-center" style={{ background: "#837b7b5c" }}>
                    <div onClick={() => setModal(false)} className="h-full w-full" ></div>
                    <div className="absolute lg:w-3/4 md:w-4/5 w-[80%] h-[600px] rounded-xl border-[1px] top-[20vh] border-slate-800 shadow-md p-4 bg-pink-200">
                        <div className="bg-white border-2 border-black rounded-md mb-5 p-3">{data[selectedItem].question}</div>
                        <textarea value={text} onChange={(e) => { setText(e.target.value) }} placeholder="Input your Question" className="p-6 w-full border-[1px] border-slate-800 h-[80%]" />
                        <div className="flex mt-4">
                            <button onClick={() => { answer() }} className="ml-auto border-[1px] border-slate-800 px-[20px] mr-5">Submit</button>
                            <button onClick={() => { setModal(false) }} className="border-[1px] border-slate-800 px-[20px]">Cancel</button>
                        </div>
                    </div>
                </div>
            ) : ""}
            {openCalculator ? (
                <div className="h-full w-full absolute top-0 left-0 flex justify-center items-center" style={{ background: "#837b7b5c" }}>
                    <div onClick={() => setOpenCalculator(false)} className="h-full w-full" ></div>
                    <div className="absolute w-[400px] h-[650px] rounded-xl border-[1px] top-[17vh] border-slate-800 shadow-md p-4 bg-pink-200">
                        <div className="bg-white h-[30%] outline-neutral-600 border-2 rounded-lg">{result}</div>
                        <div className="grid grid-cols-4 mt-7 gap-5">
                            <div onClick={() => { calculation(1) }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">1</div>
                            <div onClick={() => { calculation(2) }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">2</div>
                            <div onClick={() => { calculation(3) }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">3</div>
                            <div onClick={() => { operation("+") }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">+</div>
                            <div onClick={() => { calculation(4) }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">4</div>
                            <div onClick={() => { calculation(5) }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">5</div>
                            <div onClick={() => { calculation(6) }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">6</div>
                            <div onClick={() => { operation("-") }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">-</div>
                            <div onClick={() => { calculation(7) }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">7</div>
                            <div onClick={() => { calculation(8) }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">8</div>
                            <div onClick={() => { calculation(9) }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">9</div>
                            <div onClick={() => { operation("*") }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">*</div>
                            <div onClick={() => { calculation(0) }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">0</div>
                            <div onClick={() => { operation("=") }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">=</div>
                            <div onClick={() => { clear() }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">C</div>
                            <div onClick={() => { operation("/") }} className="bg-slate-900 h-20 flex justify-center items-center text-white text-5xl cursor-pointer">/</div>
                        </div>
                    </div>
                </div>
            ) : ""}
        </div>
    )
}