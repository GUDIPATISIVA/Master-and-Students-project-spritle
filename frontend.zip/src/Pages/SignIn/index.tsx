import { useState } from "react"
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

import Action from "../../services";

export default function SignIn() {
    const navigate = useNavigate();
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const login = async () => {
        if (username === "") {
            toast.error("Please input your username or email");
        } else if (password === "") {
            toast.error("Please input your password!");
        } else {
            const data = {
                username, password
            }
            const result = await Action.signIn(data);
            if (!result.status) {
                toast.error(result.errors);
            } else {
                localStorage.setItem("token", result.token);
                toast.success("Successfully Logged In");
                navigate("/");
            }
        }
    }

    return (
        <section className=" h-screen justify-center items-center flex">
            <div className="p-8 border-solid border-2 border-indigo-600 rounded-md w-[400px] md:w-2/3 lg:w-[500px] text-center grid-rows-4 grid gap-3">
                <div className="font-bold text-3xl">Sign In</div>
                <div>
                    <input onChange={(e) => { setUsername(e.target.value) }} value={username} className="w-full p-4 border-slate-600 border-solid border-[1px] rounded-md" placeholder="Input your email or UserName" />
                </div>
                <div>
                    <input onChange={(e) => { setPassword(e.target.value) }} value={password} type="password" className="w-full p-4 border-slate-600 border-solid border-[1px] rounded-md" placeholder="Input your Password" />
                </div>
                <button onClick={() => { login() }} className="border-slate-600 border-solid border-[1px] rounded-md bg-green-600 p-3">Sing In</button>
                <div>
                    Don't have an account? <a className="underline text-red-600" href="/signup">Register here</a>
                </div>
            </div>
        </section>
    )
}