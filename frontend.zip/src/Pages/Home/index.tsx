import { useEffect, useState } from "react"
import jwt_decode from "jwt-decode";
import { useNavigate } from "react-router-dom";

import Master from "../../components/Master";
import Student from "../../components/Student";
import Layout from "../../components/Layout";

export default function Home() {
    const navigate = useNavigate();
    const [data, setData]: any = useState([]);
    useEffect(() => {
        try {
            const token = localStorage.getItem("token");
            if (!token) {
                navigate("/signin");
            } else {
                const decode = jwt_decode(`${token}`);
                setData(decode);
            }
        } catch (error) {
            navigate("/signin");
        }
    }, [navigate])
    return (
        <Layout>
            {data.type === "master" ? <Master /> : <Student />
            }
        </Layout>
    )
}