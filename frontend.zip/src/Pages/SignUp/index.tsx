import { useState } from "react"
import { toast } from 'react-toastify';
import { useNavigate } from "react-router-dom";
import Action from "../../services";

export default function SignUp() {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [username, setUsername] = useState("");
    const [type, setType] = useState("master");
    const [password, setPassword] = useState("");
    const [confirm, setConfirm] = useState("");

    const signUp = async () => {
        if (email === "") {
            toast.error("Please input your email address");
        } else if (username === "") {
            toast.error("Please input your UserName");
        } else if (password === "") {
            toast.error("Please input your password");
        } else if (confirm === "") {
            toast.error("Please confirm your password");
        } else if (password !== confirm) {
            toast.error("Confirming password is wrong!");
        } else {
            const data = {
                email,
                username,
                type,
                password
            }
            const result = await Action.register(data);
            if (result.status === true) {
                toast.success("Successfully registed!");
                navigate("/login");
            } else {
                toast.error(result);
            }
        }
    }

    return (
        <section className=" h-screen justify-center items-center flex">
            <div className="p-8 border-solid border-2 border-indigo-600 rounded-md w-[400px] md:w-2/3 lg:w-[500px] text-center grid-rows-4 grid gap-3">
                <div className="font-bold text-3xl">Sign Up</div>
                <div>
                    <input onChange={(e) => { setEmail(e.target.value) }} value={email} className="w-full p-4 border-slate-600 border-solid border-[1px] rounded-md" placeholder="yourmail@mail.com" />
                </div>
                <div>
                    <input onChange={(e) => { setUsername(e.target.value) }} value={username} type="text" className="w-full p-4 border-slate-600 border-solid border-[1px] rounded-md" placeholder="Your User Name" />
                </div>
                <select onChange={(e) => { setType(e.target.value) }} defaultValue="master" className="flex p-4 border-slate-600 border-solid border-[1px] rounded-md">
                    <option value="master">Master</option>
                    <option value="student">Student</option>
                </select>
                <div>
                    <input onChange={(e) => { setPassword(e.target.value) }} value={password} type="password" className="w-full p-4 border-slate-600 border-solid border-[1px] rounded-md" placeholder="Input your Password" />
                </div>
                <div>
                    <input onChange={(e) => { setConfirm(e.target.value) }} value={confirm} type="password" className="w-full p-4 border-slate-600 border-solid border-[1px] rounded-md" placeholder="Confirm your Password" />
                </div>
                <button onClick={() => { signUp() }} className="border-slate-600 border-solid border-[1px] rounded-md bg-green-600 p-3">Sing Up</button>
                <div>
                    Already have an account? <a className="underline text-red-600" href="/login">Login here</a>
                </div>
            </div>
        </section>
    )
}