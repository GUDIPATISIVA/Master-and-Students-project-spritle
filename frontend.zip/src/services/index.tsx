import axios from "axios";
import { toast } from "react-toastify";

axios.defaults.baseURL = "http://192.168.112.216:5000";

const register = async (props: any) => {
    try {
        const result = await axios.post("/api/users/register", props);
        return result.data;
    } catch (error: any) {
        toast.error(error.message);
    }
}


const signIn = async (props: any) => {
    try {
        const result = await axios.post("/api/users/signIn", props);
        return result.data;
    } catch (error: any) {
        toast.error(error.message);
    }
}

const addQuestion = async (props: any) => {
    try {
        const result = await axios.post("/api/questions/addquestion", props);
        return result.data;
    } catch (error: any) {
        toast.error(error.message);
    }
}

const answerQuestion = async (props: any) => {
    try {
        const result = await axios.post("/api/questions/answerquestion", props);
        return result.data;
    } catch (error: any) {
        toast.error(error.message);
    }
}

const getQuestions = async (props: any) => {
    try {
        const result = await axios.post("/api/questions/getQuestions", props);
        return result.data;
    } catch (error: any) {
        toast.error(error.message);
    }
}

const getAllQuestions = async () => {
    try {
        const result = await axios.get("/api/questions/getAllQuestions");
        return result.data;
    } catch (error: any) {
        toast.error(error.message);
    }

}

const Action = {
    register,
    signIn,
    addQuestion,
    answerQuestion,
    getQuestions,
    getAllQuestions
}

export default Action;