const express = require("express");
const jwt = require("jsonwebtoken");
const router = express.Router();
const config = require("../config");
const { UserController } = require("../controllers/userscontroller");

router.post("/register", async (req, res) => {
    try {
        const result = await UserController.create(req.body);
        if (result) {
            res.status(200).json({ status: true });
        }
    } catch (error) {
        return res.json({ status: false, errors: error.message });
    }
})

router.post("/signIn", async (req, res) => {
    try {
        const result = await UserController.find(req.body);
        if (result) {
            const token = jwt.sign(result._doc, config.secretOrKey, { expiresIn: "144h", });
            res.status(200).json({ status: true, token: token });
        } else {
            return res.json({ status: false, errors: "Not registed user" });
        }
    } catch (error) {
        return res.json({ status: false, errors: error.message });
    }
})

module.exports = router;