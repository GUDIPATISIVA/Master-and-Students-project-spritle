const express = require("express");
const router = express.Router();
const config = require("../config");
const { QuestionContoller } = require("../controllers/questionController");

router.post("/addquestion", async (req, res) => {

    const result = await QuestionContoller.add(req.body);
    console.log(result);
    if (result) {
        res.status(200).json({ status: true });
    } else {
        res.json({ status: false });
    }
})

router.post("/getQuestions", async (req, res) => {
    const { name } = req.body;
    const result = await QuestionContoller.find({ username: name });
    if (result) {
        res.status(200).json({ status: true, result: result });
    } else {
        res.json({ status: false });
    }
})

router.post("/answerquestion", async (req, res) => {
    const result = await QuestionContoller.update(req.body);
    if (result) {
        res.status(200).json({ status: true, result: result });
    } else {
        res.json({ status: false });
    }

})

router.get("/getAllQuestions", async (req, res) => {
    const result = await QuestionContoller.find();
    if (result) {
        res.status(200).json({ status: true, result: result });
    } else {
        res.json({ status: false });
    }
})

module.exports = router;