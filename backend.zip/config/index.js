require("dotenv").config();

module.exports = {
    mongoURI: "mongodb://localhost:27017/master_studned",
    port: 5000,
    secretOrKey: process.env.TOKEN_SECRET,
}