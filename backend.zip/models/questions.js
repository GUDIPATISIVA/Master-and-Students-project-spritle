const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const AnswerSchema = new Schema({
    username: {
        type: String,
        required: true
    },
    answer: {
        type: String,
        required: true
    }
});

const QuestionBasicSchema = new Schema({
    username: {
        type: String,
        required: true
    },
    question: {
        type: String,
        required: true
    },
    answers: [AnswerSchema]
});

module.exports = Question = mongoose.model("questions", QuestionBasicSchema);