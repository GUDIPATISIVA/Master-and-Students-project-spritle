const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");
require("dotenv").config();

const users = require("./api/users");
const questions = require("./api/questions");

const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());

const mongourl = require("./config").mongoURI;

mongoose
    .connect(mongourl, {
        useUnifiedTopology: true,
        useNewUrlParser: true,
    })
    .then(() => console.log("MongoDB Connected"))
    .catch((err) => console.log(err));

app.use("/api/users", users);
app.use("/api/questions", questions);

const port = require("./config").port;
app.listen(port, () => console.log(`Server running on port ${port}`));

