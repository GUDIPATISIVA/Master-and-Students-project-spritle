const Question = require("../models/questions");

const QuestionContoller = {
    add: async (props) => {
        try {
            const { name, question } = props;
            const newQuestion = new Question({
                username: name,
                question: question,
            })

            const result = await newQuestion.save();

            return result;
        } catch {
            return false;
        }
    },
    find: async (filter) => {
        try {
            const result = await Question.find();
            return result;
        } catch {
            return false;
        }
    },
    update: async (props) => {
        try {
            const { id, username, answer } = props;
            const data = {
                username: username,
                answer: answer
            }
            const result = await Question.updateOne({ _id: id }, { $push: { answers: data } });
            return result;
        } catch (error) {
            return false
        }
    }
}

module.exports = { QuestionContoller };