const UserSchema = require("../models/users");

const UserController = {
    create: async (props) => {
        const { email, username, type, password } = props;
        var user = await UserSchema.findOne({
            $or: [{ email: email }, { username: username }]
        });
        if (user) throw new Error("Account already exist.Please log in");

        const newUser = new UserSchema({
            email,
            username,
            type,
            password
        })

        let userData = await newUser.save();

        return userData;
    },
    find: async (props) => {
        try {
            const { username, password } = props;
            var user = await UserSchema.findOne({
                $or: [{ email: username }, { username: username }]
            });
            if (user.password === password) {
                return user;
            } else {
                return false;
            }
        } catch (error) {
            return false;
        }
    }
}

module.exports = { UserController };
